#define PI 3.14 
#include<stdio.h> 
#include<conio.h> 
void main()
{
  int a,b,c = 30;
  printf("hello");
}
