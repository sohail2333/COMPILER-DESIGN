#include<stdio.h> 
void main()
{
  int a,b,c = 30;
 	printf("hello");	
}
